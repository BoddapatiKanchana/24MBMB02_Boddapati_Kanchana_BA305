# Databricks notebook source
# ==========================================================
# 02_clean_silver : Clean & Combine Bronze Data → Silver Layer
# Author: Boddapati Kanchana
# ==========================================================

from pyspark.sql import functions as F
from pyspark.sql.functions import coalesce, lower

# ✅ Step 1: Load Bronze Tables from Catalog
spotify = spark.table("workspace.default.bronze_spotify")
lyrics  = spark.table("workspace.default.bronze_lyrics")

print("✅ Bronze tables loaded successfully")
print("Spotify Rows:", spotify.count())
print("Lyrics Rows:", lyrics.count())

# ==========================================================
# ✅ Step 2: Rename Columns to Avoid Ambiguity
# ==========================================================

spotify = (spotify
           .withColumnRenamed("track_name", "spotify_song")
           .withColumnRenamed("track_artist", "spotify_artist")
           .withColumnRenamed("lyrics", "spotify_lyrics"))

lyrics = (lyrics
          .withColumnRenamed("song", "lyrics_song")
          .withColumnRenamed("artists", "lyrics_artist")
          .withColumnRenamed("lyrics", "lyrics_text"))

# ==========================================================
# ✅ Step 3: Join Datasets on Song or Artist (Case-Insensitive)
# ==========================================================

combined = spotify.join(
    lyrics,
    (lower(spotify.spotify_song) == lower(lyrics.lyrics_song)) |
    (lower(spotify.spotify_artist) == lower(lyrics.lyrics_artist)),
    "left"
).dropDuplicates(["spotify_song", "spotify_artist"])

print("✅ Join completed successfully")

# ==========================================================
# ✅ Step 4: Merge Columns and Handle Missing Values
# ==========================================================

combined = (combined
            .withColumn("lyrics", coalesce(F.col("lyrics_text"), F.col("spotify_lyrics")))
            .withColumn("song", coalesce(F.col("lyrics_song"), F.col("spotify_song")))
            .withColumn("artist", coalesce(F.col("lyrics_artist"), F.col("spotify_artist"))))

# Drop redundant columns
drop_cols = ["lyrics_text", "spotify_lyrics", "lyrics_song", "spotify_song", "lyrics_artist", "spotify_artist"]
for c in drop_cols:
    if c in combined.columns:
        combined = combined.drop(c)

print("✅ Columns merged and redundant fields removed")

# ==========================================================
# ✅ Step 5: Type Casting for Numeric Columns
# ==========================================================

num_cols = ["danceability", "energy", "valence", "tempo", "track_popularity"]
for c in num_cols:
    if c in combined.columns:
        combined = combined.withColumn(c, F.col(c).cast("double"))

print("✅ Numeric columns casted successfully")

# ==========================================================
# ✅ Step 6: Remove Duplicate or Extra Metadata Columns
# ==========================================================

# Some tables contain ingestion timestamps (_ingest_ts)
# Drop them to prevent column conflicts in Delta write
for c in combined.columns:
    if c.lower().startswith("_ingest_ts"):
        combined = combined.drop(c)

print("✅ Dropped ingestion timestamp columns")

# ==========================================================
# ✅ Step 7: Write Clean Data to Silver Layer (Managed Table)
# ==========================================================

combined.write.format("delta").mode("overwrite").saveAsTable("workspace.default.silver_songs")

print("✅ Silver Table created successfully: workspace.default.silver_songs")

# ==========================================================
# ✅ Step 8: Display Sample Records for Verification
# ==========================================================

display(spark.table("workspace.default.silver_songs").limit(5))
