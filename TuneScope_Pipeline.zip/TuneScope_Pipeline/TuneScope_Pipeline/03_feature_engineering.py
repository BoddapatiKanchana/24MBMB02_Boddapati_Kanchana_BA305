# Databricks notebook source
# ==========================================================
# 03_feature_engineering : Create Gold Layer for Use Cases
# Author: Boddapati Kanchana
# ==========================================================

from pyspark.sql import functions as F
from pyspark.sql.types import DoubleType
from pyspark.sql.functions import udf
from textblob import TextBlob

# ==========================================================
# ✅ Step 1: Load Silver Table
# ==========================================================
df = spark.table("workspace.default.silver_songs")

print("✅ Silver table loaded successfully.")
print("Total rows:", df.count(), "| Columns:", len(df.columns))

# ==========================================================
# ✅ Step 2: Add Sentiment Score using TextBlob
# ==========================================================

def get_sentiment(text):
    try:
        return float(TextBlob(text).sentiment.polarity)
    except:
        return 0.0

sent_udf = udf(get_sentiment, DoubleType())
df = df.withColumn("sentiment_score", sent_udf(F.col("lyrics")))

# Create sentiment label
df = df.withColumn(
    "sentiment_label",
    F.when(F.col("sentiment_score") > 0.1, "Positive")
     .when(F.col("sentiment_score") < -0.1, "Negative")
     .otherwise("Neutral")
)

print("✅ Sentiment analysis complete.")

# ==========================================================
# ✅ Step 3: Save Sentiment Table (Use Case 2)
# ==========================================================
df.select("song", "artist", "sentiment_score", "sentiment_label", "lyrics") \
  .write.format("delta").mode("overwrite") \
  .saveAsTable("workspace.default.gold_sentiment")

print("✅ Gold table created: workspace.default.gold_sentiment")

# ==========================================================
# ✅ Step 4: Create Genre Profile Table (Use Case 3)
# ==========================================================
if "playlist_genre" in df.columns:
    genre_profile = (df.groupBy("playlist_genre")
        .agg(
            F.avg("danceability").alias("avg_danceability"),
            F.avg("energy").alias("avg_energy"),
            F.avg("valence").alias("avg_valence"),
            F.avg("tempo").alias("avg_tempo")
        )
    )
    genre_profile.write.format("delta").mode("overwrite") \
        .saveAsTable("workspace.default.gold_genre_profile")
    print("✅ Gold table created: workspace.default.gold_genre_profile")
else:
    print("⚠️ No playlist_genre column found — skipping genre profiling.")

# ==========================================================
# ✅ Step 5: Create Artist Performance Table (Use Case 4)
# ==========================================================
artist_perf = (df.groupBy("artist")
    .agg(
        F.avg("track_popularity").alias("avg_popularity"),
        F.avg("sentiment_score").alias("avg_sentiment"),
        F.stddev("tempo").alias("tempo_variation"),
        F.countDistinct("song").alias("song_count")
    )
)
artist_perf.write.format("delta").mode("overwrite") \
    .saveAsTable("workspace.default.gold_artist_performance")

print("✅ Gold table created: workspace.default.gold_artist_performance")

# ==========================================================
# ✅ Step 6: Create Popularity Features Table (Use Case 1)
# ==========================================================
popularity_features = df.select(
    "song", "artist", "danceability", "energy", "valence",
    "acousticness", "instrumentalness", "liveness",
    "tempo", "track_popularity"
).na.drop()

popularity_features.write.format("delta").mode("overwrite") \
    .saveAsTable("workspace.default.gold_popularity_features")

print("✅ Gold table created: workspace.default.gold_popularity_features")

# ==========================================================
# ✅ Step 7: Create Cluster-Ready Table (Use Case 5)
# ==========================================================
cluster_cols = ["song", "artist", "danceability", "energy", "valence",
                "acousticness", "tempo", "sentiment_score"]

cluster_ready = df.select(*[c for c in cluster_cols if c in df.columns]).na.drop()

cluster_ready.write.format("delta").mode("overwrite") \
    .saveAsTable("workspace.default.gold_cluster_features")

print("✅ Gold table created: workspace.default.gold_cluster_features")

# ==========================================================
# ✅ Step 8: Display Samples for Verification
# ==========================================================
print("\n🎯 Feature Engineering Summary:")
display(spark.table("workspace.default.gold_sentiment").limit(5))
display(spark.table("workspace.default.gold_artist_performance").limit(5))
display(spark.table("workspace.default.gold_cluster_features").limit(5))
