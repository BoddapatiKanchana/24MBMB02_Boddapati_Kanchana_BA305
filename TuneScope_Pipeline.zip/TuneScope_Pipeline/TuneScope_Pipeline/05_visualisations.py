# Databricks notebook source
# ==========================================================
# 05_visualizations : Interactive Dashboard Visuals
# Author: Boddapati Kanchana
# ==========================================================
from pyspark.sql import functions as F

print("🎨 Creating visualizations for TuneScope 2.0 Dashboard...")

# ==========================================================
# ✅ Visualization 1 – Song Popularity Feature Importance
# ==========================================================
print("📊 Visualization 1: Song Popularity Feature Importance")
coef_df = spark.table("workspace.default.gold_popularity_features") \
    .select("danceability","energy","valence","acousticness",
            "instrumentalness","liveness","tempo","track_popularity") \
    .summary("mean")  # Placeholder for interactive bar creation
display(coef_df)
# 📌 In chart options: choose Bar Chart
# X-axis → feature names; Y-axis → mean values

# ==========================================================
# ✅ Visualization 2 – Sentiment Analysis of Lyrics
# ==========================================================
print("💬 Visualization 2: Sentiment Distribution")
sentiment_df = spark.table("workspace.default.gold_sentiment")
sent_summary = sentiment_df.groupBy("sentiment_label").count().orderBy("sentiment_label")
display(sent_summary)
# 📌 Chart type: Pie Chart
# Key → sentiment_label | Value → count

# ==========================================================
# ✅ Visualization 3 – Genre-Based Song Profiling
# ==========================================================
print("🎧 Visualization 3: Genre Energy Levels")
if "workspace.default.gold_genre_profile" in [t.name for t in spark.catalog.listTables("workspace.default")]:
    genre_df = spark.table("workspace.default.gold_genre_profile")
    display(genre_df)
    # 📌 Chart type: Bar Chart
    # X → playlist_genre | Y → avg_energy
else:
    print("⚠️ Genre table not found – skipping.")

# ==========================================================
# ✅ Visualization 4 – Artist Performance Analysis
# ==========================================================
print("🎤 Visualization 4: Artist Performance & Popularity")
artist_df = spark.table("workspace.default.gold_artist_performance")
top10 = artist_df.orderBy(F.col("avg_popularity").desc()).limit(10)
display(top10)
# 📌 Chart type: Horizontal Bar
# X → avg_popularity | Y → artist

# ==========================================================
# ✅ Visualization 5 – Song Clustering
# ==========================================================
print("🎶 Visualization 5: Song Clustering (Musical + Emotional Similarity)")
cluster_df = spark.table("workspace.default.gold_cluster_features")
display(cluster_df)
# 📌 Chart type: Scatter Plot
# X → danceability | Y → energy | Color → sentiment_score or cluster group

print("\n✅ All charts ready. Add each one to your TuneScope Dashboard.")
