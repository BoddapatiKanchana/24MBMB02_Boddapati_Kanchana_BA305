# Databricks notebook source
# ==========================================================
# master_pipeline_runner : CE-compatible reliable pipeline
# Author: Boddapati Kanchana
# ==========================================================

import time

print("🚀 Starting TuneScope pipeline execution...")

try:
    # ---- Step 1 ----
    print("\n▶ Running: 01_ingest_bronze")
    dbutils.notebook.run("01_ingest_bronze", 0)
    print("✅ Step 1 completed.\n")

    # ---- Step 2 ----
    print("\n▶ Running: 02_clean_silver")
    dbutils.notebook.run("02_clean_silver", 0)
    print("✅ Step 2 completed.\n")

    # ---- Step 3 ----
    print("\n⚠️ Step 3 (03_feature_engineering) is resource-heavy and may fail in Community Edition.")
    print("👉 Please open '03_feature_engineering' notebook manually and run it fully.")
    input("⏸ Press Enter here after you’ve finished running 03_feature_engineering manually...")

    # ---- Step 4 ----
    print("\n▶ Running: 04_models_and_usecases")
    dbutils.notebook.run("04_models_and_usecases", 0)
    print("✅ Step 4 completed.\n")

    # ---- Step 5 ----
    print("\n▶ Running: 05_visualisations")
    dbutils.notebook.run("05_visualisations", 0)
    print("✅ Step 5 completed.\n")

    print("\n🎯 TuneScope pipeline executed successfully! Dashboard visuals ready.")

except Exception as e:
    print("❌ Pipeline failed:", e)
    raise
