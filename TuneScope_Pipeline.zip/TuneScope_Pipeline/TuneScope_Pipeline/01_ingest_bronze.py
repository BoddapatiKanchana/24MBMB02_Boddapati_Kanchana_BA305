# Databricks notebook source
from pyspark.sql import functions as F
from datetime import datetime

# ✅ Load existing catalog tables
spotify_df = spark.table("workspace.default.spotify_songs")
lyrics_df  = spark.table("workspace.default.lyrics_10_k")

# ✅ Add ingestion timestamp
ts = datetime.now().isoformat()
spotify_df = spotify_df.withColumn("_ingest_ts", F.lit(ts))
lyrics_df  = lyrics_df.withColumn("_ingest_ts", F.lit(ts))

# ✅ Instead of saving to /delta/... paths, save as managed tables in your catalog
spotify_df.write.format("delta").mode("overwrite").saveAsTable("workspace.default.bronze_spotify")
lyrics_df.write.format("delta").mode("overwrite").saveAsTable("workspace.default.bronze_lyrics")

# ✅ Check results
display(spark.table("workspace.default.bronze_spotify").limit(5))
display(spark.table("workspace.default.bronze_lyrics").limit(5))
