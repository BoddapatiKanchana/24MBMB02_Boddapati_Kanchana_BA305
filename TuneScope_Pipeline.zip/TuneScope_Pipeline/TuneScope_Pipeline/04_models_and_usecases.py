# Databricks notebook source
# ==========================================================
# 04_models_and_usecases : Analytics & ML Modeling
# Author: Boddapati Kanchana
# ==========================================================

from pyspark.sql import functions as F
from pyspark.ml.feature import VectorAssembler
from pyspark.ml.regression import LinearRegression
from pyspark.ml.evaluation import RegressionEvaluator
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.cluster import MiniBatchKMeans

# ==========================================================
# ✅ Step 1: Use Case 1 — Song Popularity Prediction
# ==========================================================

print("🎵 Use Case 1: Song Popularity Prediction")

pop_df = spark.table("workspace.default.gold_popularity_features").na.drop()

feature_cols = ['danceability','energy','valence','acousticness',
                'instrumentalness','liveness','tempo']

assembler = VectorAssembler(inputCols=feature_cols, outputCol="features")
data = assembler.transform(pop_df).select("features", F.col("track_popularity").alias("label"))
train, test = data.randomSplit([0.8, 0.2], seed=42)

lr = LinearRegression(featuresCol="features", labelCol="label")
lr_model = lr.fit(train)
predictions = lr_model.transform(test)

r2 = RegressionEvaluator(labelCol="label", predictionCol="prediction", metricName="r2").evaluate(predictions)
print(f"✅ Model trained successfully | R² Score: {r2:.3f}")

# Convert coefficients to a Spark DataFrame for dashboard
coef_data = [(f, float(c)) for f, c in zip(feature_cols, lr_model.coefficients.toArray())]
coef_df = spark.createDataFrame(coef_data, ["Feature", "Coefficient"])
display(coef_df)   # ➡️ Use Bar Chart (x=Feature, y=Coefficient)

# ==========================================================
# ✅ Step 2: Use Case 2 — Sentiment Analysis of Lyrics
# ==========================================================

print("💬 Use Case 2: Sentiment Analysis of Lyrics")

sentiment_df = spark.table("workspace.default.gold_sentiment")
sent_summary = sentiment_df.groupBy("sentiment_label").count().orderBy("sentiment_label")
display(sent_summary)   # ➡️ Choose Pie Chart (Key=sentiment_label, Value=count)

# ==========================================================
# ✅ Step 3: Use Case 3 — Genre-Based Song Profiling
# ==========================================================

print("🎧 Use Case 3: Genre Profiling")

if "workspace.default.gold_genre_profile" in [t.name for t in spark.catalog.listTables("workspace.default")]:
    genre_df = spark.table("workspace.default.gold_genre_profile").orderBy(F.col("avg_energy").desc())
    display(genre_df)   # ➡️ Bar Chart (x=playlist_genre, y=avg_energy)
else:
    print("⚠️ Genre table not found — skipping.")

# ==========================================================
# ✅ Step 4: Use Case 4 — Artist Performance and Diversity
# ==========================================================

print("🎤 Use Case 4: Artist Performance and Diversity Analysis")

artist_df = spark.table("workspace.default.gold_artist_performance")
top_artists = artist_df.orderBy(F.col("avg_popularity").desc()).limit(10)
display(top_artists)    # ➡️ Horizontal Bar (x=avg_popularity, y=artist)

# ==========================================================
# ✅ Step 5: Use Case 5 — Song Clustering (Musical + Emotional Similarity)
# ==========================================================

print("🎶 Use Case 5: Song Clustering — Musical + Emotional Similarity")

cluster_df = spark.table("workspace.default.gold_cluster_features").na.drop()
sample_df = cluster_df.limit(3000).toPandas()

# Prepare features
X = sample_df[['danceability','energy','valence','acousticness','tempo','sentiment_score']].values
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# MiniBatch KMeans (lightweight for Databricks CE)
kmeans = MiniBatchKMeans(n_clusters=4, batch_size=100, random_state=42)
labels = kmeans.fit_predict(X_scaled)

# PCA for 2-D visualization
pca = PCA(n_components=2, random_state=42)
pca_result = pca.fit_transform(X_scaled)

viz_pd = pd.DataFrame({
    "pc1": pca_result[:,0],
    "pc2": pca_result[:,1],
    "cluster": labels
})

viz_spark = spark.createDataFrame(viz_pd)
display(viz_spark)   # ➡️ Scatter Plot (x=pc1, y=pc2, Color=cluster)

# ==========================================================
# ✅ Step 6: Display Completion Summary
# ==========================================================
print("\n✅ All five use cases executed successfully.")
print("Results and visualizations ready for Dashboard creation.")


# COMMAND ----------

